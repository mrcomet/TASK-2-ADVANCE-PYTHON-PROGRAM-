#!/usr/bin/env python
# coding: utf-8

# # Q1. Defanging an IP Address

# In[ ]:


class Solution(object):
    def defangIPaddr(self, address):
        ans=address.replace(".","[.]")
        return ans


# # Q2. Find Numbers with Even Number of Digits

# In[ ]:


class Solution:
    def findNumbers(self, nums: List[int]) -> int:
        count=0
        for i in nums:
            if len(str(i))%2==0:
                count+=1
        return count


# # Q3. Number of Good Pairs

# In[ ]:


d={}
count= 0
for i in nums:
    if i in d:
        if d[i]==1:
            count+=1
        else:
            count+=d[i]
            d[i]+=1 # if i is in  nums d[i] will always increase
    else:
        d[i]=1
print(count)


# # Q4. How Many Numbers Are Smaller Than the Current Number

# In[ ]:


class Solution:
    def smallerNumbersThanCurrent(self, nums: List[int]) -> List[int]:
        l=len(nums)
        ans=[]
        count=0
        for i in nums:
            for j in range(l):
                if (nums[j]-i)<0:
                    count+=1
            ans.append(count)
            count=0
        return ans


# # Q5. Subtract the Product and Sum of Digits of an Integer

# In[ ]:


class Solution:
    def subtractProductAndSum(self, n: int) -> int:
        str_n = str(n)
        product_of_digits = 1
        sum_of_digits = 0
        for number in str_n:
            int_n = int(number)
            product_of_digits *= int_n
            sum_of_digits += int_n
            diff = product_of_digits - sum_of_digits
        return diff
        


# # Q6. XOR Operation in an Array

# In[ ]:


class Solution:
    def xorOperation(self, n: int, start: int) -> int:
        result = 0

        for i in range(n):                
            result = result ^ (start + 2*i)
        
        return result
        

